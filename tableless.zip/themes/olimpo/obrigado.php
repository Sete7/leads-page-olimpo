<div id="banner">
    <div id="banner_formulario">
        <div id="banner_desc">
            <h1>
                <strong>Obrigado por<br/>
                    entrar em contato!</strong> <br/>
                <span>Em breve retornaremos<br/>
                    seu contato.</span>
            </h1>
        </div>                    
    </div> 
    <!--FECHA BANNER TOPO-->
</div> 
<!--FECHANDO ID BOX-->        
